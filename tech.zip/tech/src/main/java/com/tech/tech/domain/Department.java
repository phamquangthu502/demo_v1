package com.tech.tech.domain;

import com.tech.tech.base.BaseObject;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.util.Set;

@Data
@Entity
@Table(name = "tbl_department")
public class Department extends BaseObject {

    @Column(name = "code")
    private String code;

    @Column(name = "name")
    private String name;

    @ManyToMany(mappedBy = "likedDepartment")
    Set<Employee> likedEmployee;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Employee> getLikedEmployee() {
        return likedEmployee;
    }

    public void setLikedEmployee(Set<Employee> likedEmployee) {
        this.likedEmployee = likedEmployee;
    }
}