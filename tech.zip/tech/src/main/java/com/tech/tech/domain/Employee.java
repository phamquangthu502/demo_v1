package com.tech.tech.domain;

import com.tech.tech.base.BaseObject;
import lombok.Data;

import javax.persistence.*;
import java.util.Set;

@Data
@Entity
@Table(name = "tbl_employee")
public class Employee extends BaseObject {

    @Column(name = "code")
    private String code;

    @Column(name = "name")
    private String name;

    @Column(name = "username")
    private String username;

    @Column(name = "password")
    private String password;

    @Column(name = "email")
    private String email;

    @Column(name="position")
    private String position;

    @ManyToMany
    @JoinTable(
            name = "tbl_employee_department",
            joinColumns = @JoinColumn(name = "employee_id"),
            inverseJoinColumns = @JoinColumn(name = "department_id"))
    Set<Department> likedDepartment;

    @ManyToMany
    @JoinTable(
            name = "tbl_user_role",
            joinColumns = @JoinColumn(name = "employee_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    Set<Role> likedRole;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Department> getLikedDepartment() {
        return likedDepartment;
    }

    public void setLikedDepartment(Set<Department> likedDepartment) {
        this.likedDepartment = likedDepartment;
    }

    public Set<Role> getLikedRole() {
        return likedRole;
    }

    public void setLikedRole(Set<Role> likedRole) {
        this.likedRole = likedRole;
    }
}
