package com.tech.tech.base;


import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import org.hibernate.annotations.Type;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

@MappedSuperclass
public class BaseObject implements Serializable {
    @Id
    @Type(
            type = "uuid-char"
    )
    @Column(
            name = "id",
            unique = true,
            nullable = false
    )
    private UUID id;

    @Column(
            name = "create_date",
            nullable = false
    )
    private LocalDateTime createDate;
    @Column(
            name = "created_by",
            length = 100,
            nullable = false
    )
    private String createdBy;
    @Column(
            name = "modify_date",
            nullable = true
    )
    private LocalDateTime modifyDate;
    @Column(
            name = "modified_by",
            length = 100,
            nullable = true
    )
    private String modifiedBy;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

//    public LocalDateTime getCreateDate() {
//        return createDate;
//    }
//
//    public void setCreateDate(LocalDateTime createDate) {
//        this.createDate = createDate;
//    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

//    public LocalDateTime getModifyDate() {
//        return modifyDate;
//    }
//
//    public void setModifyDate(LocalDateTime modifyDate) {
//        this.modifyDate = modifyDate;
//    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public BaseObject() {
        if (this.id == null) {
            this.id = UUID.randomUUID();
        }


    }

    public BaseObject(BaseObject entity) {
        if (entity != null) {
            this.id = entity.getId();
            this.modifiedBy = entity.modifiedBy;
            //this.modifyDate = entity.modifyDate;
            this.createdBy = entity.createdBy;
            //this.createDate = entity.createDate;
        }

    }
}
