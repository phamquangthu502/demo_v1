package com.tech.tech.domain;

import com.tech.tech.base.BaseObject;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.Set;

@Data
@Entity
@Table(name = "tbl_role")
public class Role extends BaseObject {

    @Column(name = "name")
    private String name;

    @ManyToMany(mappedBy = "likedRole")
    Set<Employee> likedEmployee;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Employee> getLikedEmployee() {
        return likedEmployee;
    }

    public void setLikedEmployee(Set<Employee> likedEmployee) {
        this.likedEmployee = likedEmployee;
    }

}
