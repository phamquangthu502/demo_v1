package com.bezkoder.springjwt.service.impl;

import com.bezkoder.springjwt.domain.Employee;
import com.bezkoder.springjwt.dto.EmployeeDto;
import com.bezkoder.springjwt.repository.EmployeeRepository;
import com.bezkoder.springjwt.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    EmployeeRepository repo;

    @Override
    public EmployeeDto saveOrUpdate(Long id, EmployeeDto dto) {
        if (dto != null) {
            Employee entity = null;
            if (dto.getId() != null) {
                if (dto.getId() != null && !dto.getId().equals(id)) {
                    return null;
                }
                entity = repo.getById(dto.getId());
            }
            if (entity == null) {
                entity = new Employee();
            }
            entity.setName(dto.getName());

            entity = repo.save(entity);
//            if (entity != null) {
//                return new TinhDto(entity);
//            }
        }
        return null;
    }

    @Override
    public List<EmployeeDto> getAll() {
        return repo.getListEmployee();
    }
}
