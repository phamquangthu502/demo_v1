package com.bezkoder.springjwt.repository;

import com.bezkoder.springjwt.domain.Employee;
import com.bezkoder.springjwt.dto.EmployeeDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    @Query("select new com.bezkoder.springjwt.dto.EmployeeDto(em) from Employee em")
    List<EmployeeDto> getListEmployee();
}
