package com.bezkoder.springjwt.service;

import com.bezkoder.springjwt.dto.EmployeeDto;

import java.util.List;

public interface EmployeeService {
    public EmployeeDto saveOrUpdate(Long id, EmployeeDto dto);

    public List<EmployeeDto> getAll();
}
