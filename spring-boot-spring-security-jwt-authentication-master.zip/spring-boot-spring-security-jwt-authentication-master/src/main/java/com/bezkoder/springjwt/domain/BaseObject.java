package com.bezkoder.springjwt.domain;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@MappedSuperclass
public class BaseObject implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(
            name = "create_date",
            nullable = false
    )
    private LocalDateTime createDate;
    @Column(
            name = "created_by",
            length = 100,
            nullable = false
    )
    private String createdBy;
    @Column(
            name = "modify_date",
            nullable = true
    )
    private LocalDateTime modifyDate;
    @Column(
            name = "modified_by",
            length = 100,
            nullable = true
    )
    private String modifiedBy;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
