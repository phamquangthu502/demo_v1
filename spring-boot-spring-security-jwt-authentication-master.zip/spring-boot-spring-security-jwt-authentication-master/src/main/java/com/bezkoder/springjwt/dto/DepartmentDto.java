package com.bezkoder.springjwt.dto;

import lombok.Data;

@Data
public class DepartmentDto {
    private String code;
    private String name;
}
